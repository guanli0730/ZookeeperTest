create function table_space(towner in varchar2,
                                       tname  in varchar2) return varchar2 as
  v_tmp varchar2(300);
begin
  for ts in (select t.tablespace_name
               from all_tables t
              where t.table_name = tname
                and t.owner = towner) loop
    v_tmp := ts.tablespace_name;
  end loop;

  return(v_tmp);
end table_space;

