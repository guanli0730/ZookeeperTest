create procedure belong_by_zhuangyu(SQLTEXT  in Varchar2)
authid current_user as
begin
dbms_output.put_line('start');
      execute immediate SQLTEXT;
dbms_output.put_line('end');
end belong_by_zhuangyu;
