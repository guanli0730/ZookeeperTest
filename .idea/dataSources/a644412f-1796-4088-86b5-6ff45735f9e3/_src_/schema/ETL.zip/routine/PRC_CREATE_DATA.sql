create procedure prc_create_data is
  pkname       varchar2(1000);
  colsinfo     varchar2(3000);
  v_index_num  number(10) := 0;
  v_index_cols varchar2(100);
  v_count      number(10) := 0;
  v_index      varchar2(1000);
  v_space      varchar2(100);
  v_pk_space   varchar2(100);

begin
  for tab in (select * from dbm_scheme_table) loop
    begin
      update dbm_scheme_table d
         set d.table_owner = upper(d.table_owner)
       where d.table_name = tab.table_name;
       update dbm_scheme_table d
           set d.tactics = trim(d.tactics)
        where d.table_name = tab.table_name;
      commit;
    exception
      when others then
        rollback;
    end;

    begin
      pkname   := table_pk(tab.table_owner, tab.table_name);
      colsinfo := table_columns_info(tab.table_owner, tab.table_name);
      v_space  := table_space(tab.table_owner, tab.table_name);
      update dbm_scheme_table d
         set d.pk_names         = pkname,
             d.columns_name     = colsinfo,
             d.table_tablespace = v_space
       where d.table_name = tab.table_name;
      commit;
    exception
      when others then
        rollback;
    end;

    begin
      select (all_indexes.tablespace_name) into v_pk_space
               from all_constraints, all_indexes
              where all_constraints.owner = all_indexes.owner
                and all_constraints.table_name = all_indexes.table_name
                and all_indexes.index_name=all_constraints.constraint_name
                and all_constraints.constraint_type = 'P'
                and all_constraints.owner = tab.table_owner
                and all_constraints.table_name = tab.table_name;
     dbms_output.put_line(v_pk_space);
     update dbm_scheme_table d
        set d.pk_tablespace =v_pk_space
      where d.table_name = tab.table_name and d.table_owner=tab.table_owner;
      commit;
    exception
      when others then
        rollback;
    end;

    v_index_num := 0;
    select count(*)
      into v_index_num
      from all_indexes
     where table_name = tab.table_name
       and owner = tab.table_owner
       and index_name not in
           (select constraint_name
              from all_constraints
             where table_name = tab.table_name
               and constraint_type = 'P');

    if (v_index_num > 8) then
      v_index_num := 8;
    end if;
    v_count := 0;
    for idx in (select *
                  from all_indexes
                 where table_name = tab.table_name
                   and owner = tab.table_owner
                   and index_name not in
                       (select constraint_name
                          from all_constraints
                         where table_name = tab.table_name
                           and owner = tab.table_owner
                           and constraint_type = 'P')) loop

      v_index_cols := table_index(tab.table_owner, idx.index_name);
      v_count      := v_count + 1;

      if (v_count <= v_index_num and v_index_cols is not null) then
        v_index := 'update dbm_scheme_table set index' || v_count ||
                   ' = ''' || v_index_cols || '''' || ',' || ' index' ||
                   v_count || '_tablespace = ''' || idx.tablespace_name ||
                   ''' where table_name = ''' || tab.table_name || '''';

        begin
          execute immediate v_index;
          commit;
        exception
          when others then
            rollback;
        end;
        /*dbms_output.put_line(v_index);*/
      end if;
    end loop;
  end loop;
end prc_create_data;
