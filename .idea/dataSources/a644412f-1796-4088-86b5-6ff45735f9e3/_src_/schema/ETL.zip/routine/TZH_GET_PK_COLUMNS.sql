create FUNCTION TZH_GET_PK_COLUMNS
(
  t_owner IN VARCHAR2,
  t_tab_name IN VARCHAR2,
  t_idx_name IN VARCHAR2
) RETURN VARCHAR2 AS
  CURSOR c IS
         SELECT *
         FROM ALL_IND_COLUMNS T
         WHERE T.INDEX_NAME = t_idx_name
           AND T.TABLE_NAME = t_tab_name
           AND T.TABLE_OWNER = t_owner
         ORDER BY T.COLUMN_POSITION;
  tab   c%ROWTYPE;
  s2    VARCHAR2(1000);
  num   NUMBER(20);
  c_num NUMBER(20) := 0;
BEGIN
  IF t_owner IS NULL THEN
     RETURN(NULL);
  END IF;
  IF t_tab_name IS NULL THEN
     RETURN(NULL);
  END IF;
  IF t_idx_name IS NULL THEN
     RETURN(NULL);
  END IF;

  OPEN c;
  FETCH c INTO tab;
  WHILE c%FOUND LOOP
    SELECT COUNT(*)
        INTO num
        FROM ALL_IND_COLUMNS T
       WHERE T.INDEX_NAME = t_idx_name
         AND T.TABLE_NAME = t_tab_name
         AND T.TABLE_OWNER = t_owner;

       s2:=s2||tab.column_name;
       c_num:=c_num+1;
       IF(c_num<num) THEN
         s2:=s2||',';
       END IF;
    FETCH c INTO tab;
  END LOOP;
  CLOSE c;
  RETURN(s2);

END TZH_GET_PK_COLUMNS;
