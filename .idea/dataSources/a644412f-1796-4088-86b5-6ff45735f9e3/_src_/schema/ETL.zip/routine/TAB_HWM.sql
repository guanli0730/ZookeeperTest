create PROCEDURE
--
	--计算表的高水位,luzp@asiainfo-linkage.com,2008-2011
	--Changed log:
	--2008,created
	--2011,change some output format.
	--
 tab_hwm(Tabname        VARCHAR2,
		 Owner          VARCHAR2 := SYS_CONTEXT('USERENV', 'CURRENT_USER'),
		 Use_stat_value BOOLEAN := FALSE) AUTHID CURRENT_USER IS
	l_owner              VARCHAR2(32) := upper(TRIM(owner));
	l_tabname            VARCHAR2(32) := upper(TRIM(tabname));
	l_estimate_seg_size  NUMBER;
	l_allocated_seg_size NUMBER;
	l_num_rows           NUMBER;
	l_rows_per_blk       NUMBER;
	l_blocks             NUMBER;
	l_initrans           NUMBER;
	l_partitioned        VARCHAR2(3);
	l_part_name          VARCHAR2(32);
	l_tbs_name           VARCHAR2(30);
	l_avg_row_len        NUMBER;
	l_pctfree            NUMBER;
	--l_error              BOOLEAN := TRUE;
	l_blk_size      NUMBER;
	l_blk_cnt       NUMBER;
	l_last_analyzed DATE;
	l_sql           VARCHAR2(32767);
	--------------
	--需要权限：
	-- grant select on dba_segments to &proc_owner;
	-- grant select any table to &proc_owner;
	--注：
	--计算块内的行数，相关算法见附3
	--块相关部分尺寸信息,取自v$type_size
	l_blk_common_header         NUMBER := 20; --
	l_blk_data_header           NUMBER := 14;
	l_blk_trans_fixed_header    NUMBER := 24;
	l_blk_trans_variable_header NUMBER := 24;
	l_blk_unknw_after_x_var_hdr NUMBER := 8;
	--
	l_blk_tail_field    NUMBER := 4; --
	l_blk_table_dir     NUMBER := 4; --4*num of table ,for non-cluster table ,this value always is 4
	l_blk_row_dir_index NUMBER := 2; --2*num of rows in the block
	l_blk_row_header    NUMBER := 3;

	CURSOR cur_tab_cols(p_owner all_tab_columns.owner%TYPE, p_tab_name all_tables.table_name%TYPE) IS
		SELECT COLUMN_NAME, data_type --, COLUMN_ID
		  FROM all_tab_columns
		 WHERE table_name = p_tab_name
		   AND owner = p_owner
		 ORDER BY COLUMN_ID;
BEGIN
	--输入参数合法性判断
	IF l_owner IS NULL OR l_tabname IS NULL THEN
		dbms_output.put_line('Wrong Input parameter,Quit!');
		RETURN;
	END IF;
	--
	SELECT INI_TRANS,
		   PCT_FREE,
		   last_analyzed,
		   AVG_ROW_LEN,
		   NUM_ROWS,
		   BLOCKS,
		   tablespace_name,
		   PARTITIONED
	  INTO l_initrans,
		   l_pctfree,
		   l_last_analyzed,
		   l_avg_row_len,
		   l_num_rows,
		   l_blocks,
		   l_tbs_name,
		   l_partitioned
	  FROM all_tables
	 WHERE owner = l_Owner
	   AND TABLE_NAME = l_tabname;

	IF l_partitioned IS NULL THEN
		--没有记录
		dbms_output.put_line('Can not find table,Quit!');
		RETURN;
	ELSIF l_partitioned = 'YES' THEN
		--分区表
		SELECT MAX(INI_TRANS),
			   MAX(PCT_FREE),
			   MAX(last_analyzed),
			   MAX(AVG_ROW_LEN),
			   SUM(NUM_ROWS),
			   SUM(BLOCKS),
			   MAX(tablespace_name)
		  INTO l_initrans,
			   l_pctfree,
			   l_last_analyzed,
			   l_avg_row_len,
			   l_num_rows,
			   l_blocks,
			   l_tbs_name
		  FROM all_TAB_PARTITIONS
		 WHERE TABLE_owner = l_Owner
		   AND TABLE_NAME = l_tabname;
	END IF;

	IF Use_stat_value = TRUE AND l_last_analyzed IS NULL THEN
		--使用统计值来计算表的空间使用量，但表未分析
		dbms_output.put_line('This Table has not been analyzed,Quit!');
		RETURN;
	END IF;

	--SELECT block_size INTO l_blk_size FROM dba_tablespaces WHERE tablespace_name = l_tbs_name;
	l_blk_size := 8192;

	SELECT SUM(bytes / 1024 / 1024)
	  INTO l_allocated_seg_size
	  FROM dba_segments
	 WHERE owner = l_owner
	   AND segment_name = l_tabname
	   AND SEGMENT_TYPE IN ('TABLE', 'TABLE PARTITION');

	IF Use_stat_value = FALSE THEN
		--实时计算
		--统计表记录数
		l_sql := 'select count(*) from ' || l_owner || '.' || l_tabname;
		EXECUTE IMMEDIATE l_sql
			INTO l_num_rows;

		--计算表平均行长度,只计算表的前100000行.算法见末尾附2
		--l_error := FALSE;
		l_sql := 'select ROUND(avg(';
		FOR tab_col IN cur_tab_cols(l_owner, l_tabname) LOOP
			IF tab_col.data_type IN ('BLOB', 'CLOB', 'LONG', 'LONG RAW', 'NCLOB', 'RAW') THEN
				--l_error := TRUE;
				dbms_output.put_line('This table include some big object column,Quit!');
				RETURN;
			END IF;
			l_sql := l_sql || 'nvl(VSIZE(' || tab_col.column_name || '),0)+decode(trunc(nvl(VSIZE(' ||
					 tab_col.column_name || '),0)/250),0,1,3)+';
		END LOOP;

		l_sql := l_sql || '0),2) from ' || l_owner || '.' || l_tabname || ' where rownum<100000';
		EXECUTE IMMEDIATE l_sql
			INTO l_avg_row_len;
	END IF;

	--是否使用统计值仅涉及：l_num_rows和l_avg_row_len
	/*
    pctfree:仅针对data layer而言，即包含rowdata、rowdir 、tabdir、freespace
    ( l_blk_size -
        l_blk_common_header -
        l_blk_data_header -
        l_blk_trans_fixed_header -
        l_blk_unknw_after_x_var_hdr -
        l_blktrans_variable_header*l_initrans -
        l_blk_tail_field
     ) * (100 - l_pctfree) / 100 -
    l_blk_table_dir
        = l_rows_per_blk * (l_avg_row_len + l_blk_row_dir_index + l_blk_row_header)
    */
	IF l_initrans = 1 THEN
		l_initrans := 2; --9ir2,表的最小initrans为2,即使在建表的时候指定为1
	END IF;

	l_rows_per_blk      := (l_blk_size - --
						   l_blk_common_header - --
						   l_blk_data_header - --
						   l_blk_trans_fixed_header - --
						   l_blk_trans_variable_header * l_initrans - --9ir2,表的最小initrans为2,即使在建表的时候指定为1
						   l_blk_unknw_after_x_var_hdr - --
						   l_blk_tail_field - --
						   l_blk_table_dir) / (l_blk_row_dir_index + l_blk_row_header +
						   100 * l_avg_row_len / (100 - l_pctfree));
	l_blk_cnt           := l_num_rows / l_rows_per_blk;
	l_estimate_seg_size := round(l_blk_cnt * l_blk_size / 1024 / 1024, 2);

	IF Use_stat_value = TRUE THEN
		dbms_output.put_line(l_owner||'.'||l_tabname||' space usage stat(estimate with stat data):');
		dbms_output.put_line(rpad('Last_analyzed ', 40, '-') ||
							 to_char(l_last_analyzed, 'yyyymmdd hh24:mi:ss'));
	ELSE
		dbms_output.put_line(l_owner||'.'||l_tabname||' space usage stat(estimate with real data):');
	END IF;
	dbms_output.put_line('***********************************************');
	dbms_output.put_line(rpad('Allocated space Size(MB) ', 40, '-') ||
						 TRUNC(l_allocated_seg_size, 2));
	--ADD HWM_MB ONLY WHEN USE STATS DATA
	IF USE_STAT_VALUE = TRUE THEN
		dbms_output.put_line(rpad('Hign Water Mark(MB) ', 40, '-') ||
							 trunc(l_blocks * l_blk_size / 1024 / 1024, 2));
	END IF;
	dbms_output.put_line(rpad('Estimate space Size(MB) ', 40, '-') || l_estimate_seg_size);
	dbms_output.put_line(rpad('Estimate rows/blk ', 40, '-') || round(l_rows_per_blk, 2));
	dbms_output.put_line(rpad('Num_rows ', 40, '-') || l_num_rows);
	dbms_output.put_line(rpad('Avg_row_len(bytes) ', 40, '-') || l_avg_row_len);
	dbms_output.put_line(rpad('Pctfree ', 40, '-') || l_pctfree);
	dbms_output.put_line(rpad('Ini_trans ', 40, '-') || l_initrans);

END;

	--附1：参考数据
	/*
    SELECT OWNER, TABLE_NAME, INI_TRANS, PCT_FREE, PARTITIONED, AVG_ROW_LEN, NUM_ROWS, BLOCKS / 128,tablespace_name
      FROM all_tables
     WHERE owner = 'ZK'
       AND TABLE_NAME IN ('CM_BUSI', 'CM_BUSI_PROVISION_SMC_A');

    OWNER   TABLE_NAME                 INI_TRANS     PCT_FREE    PARTITIONED    LAST_ANALYZED           AVG_ROW_LEN   NUM_ROWS    BLOCKS/128    TABLESPACE_NAME
    -----   ----------                 ---------     --------    -----------    -------------           -----------   --------    ----------    ---------------
    ZK      CM_BUSI                                              YES            2007-02-05 22:23:00     201           10553820    3557.828125
    ZK      CM_BUSI_PROVISION_SMC_A    36            30          NO             2007-02-05 22:27:25     146           37122       12.28125      TS_QUEUE_1M_01

    =======================
    SELECT table_owner, table_name, partition_name, tablespace_name, pct_free, ini_trans, num_rows,
           blocks
      FROM all_tab_partitions
     WHERE table_owner = 'ZK'
       AND TABLE_NAME = 'CM_BUSI';
    TABLE_OWNER   TABLE_NAME  PARTITION_NAME   TABLESPACE_NAME  PCT_FREE INI_TRANS  NUM_ROWS  BLOCKS
    -----------   ----------  --------------   ---------------  -------- ---------  --------  ------
    ZK            CM_BUSI     P0410            TS_SO_4M_08      25       64         7639      502
    ZK            CM_BUSI     P0411            TS_SO_4M_07      25       64         862       118
    ZK            CM_BUSI     P0412            TS_SO_4M_06      25       64         991       54
    ZK            CM_BUSI     P0501            TS_SO_4M_05      25       64         208       118
    ZK            CM_BUSI     P0502            TS_SO_4M_04      25       64         163       118
    ZK            CM_BUSI     P0503            TS_SO_4M_03      25       64         125       118
    ZK            CM_BUSI     P0504            TS_SO_4M_02      25       64         192       118
    ZK            CM_BUSI     P0505            TS_SO_4M_01      25       64         123       118
    ZK            CM_BUSI     P0506            TS_SO_4M_08      25       64         384       118
    ZK            CM_BUSI     P0508            TS_SO_4M_06      25       64         231       118
    ZK            CM_BUSI     P0509            TS_SO_4M_05      25       64         305       118
    ZK            CM_BUSI     P0510            TS_SO_4M_04      25       64         291652    13422
    ZK            CM_BUSI     P0511            TS_SO_4M_03      25       64         23744     1126
    ZK            CM_BUSI     P0512            TS_SO_4M_02      25       64         24296     1126
    ZK            CM_BUSI     P0601            TS_SO_4M_01      25       64         2694      182
    ZK            CM_BUSI     P0602            TS_SO_4M_08      25       64         1622      182
    ZK            CM_BUSI     P0603            TS_SO_4M_07      25       64         2179      182
    ZK            CM_BUSI     P0604            TS_SO_4M_06      25       64         767       118
    ZK            CM_BUSI     P0605            TS_SO_4M_05      25       64         557       118
    ZK            CM_BUSI     P0606            TS_SO_4M_04      25       64         901       118
    ZK            CM_BUSI     P0607            TS_SO_4M_03      25       64         4052      246
    ZK            CM_BUSI     P0608            TS_SO_4M_02      25       64         1284      118
    ZK            CM_BUSI     P0609            TS_SO_4M_01      25       64         1236      118
    ZK            CM_BUSI     P0610            TS_SO_4M_08      25       64         1544      182
    ZK            CM_BUSI     P0611            TS_SO_4M_07      25       64         1450      118
    ZK            CM_BUSI     P0612            TS_SO_4M_06      25       64         1467      182
    ZK            CM_BUSI     P0701            TS_SO_4M_05      25       64         9281608   398500
    ZK            CM_BUSI     P0702            TS_SO_4M_04      25       64         890196    37628
    ZK            CM_BUSI     P0703            TS_SO_4M_03      25       64         0         0
    ZK            CM_BUSI     P0507            TS_SO_4M_07      25       64         280       118
    ZK            CM_BUSI     P0704            TS_SO_4M_02      25       64         0         0
    ZK            CM_BUSI     P0705            TS_SO_4M_01      25       64         0         0
    ZK            CM_BUSI     P0706            TS_SO_4M_08      25       64         0         0
    ZK            CM_BUSI     P0707            TS_SO_4M_07      25       64         0         0
    ZK            CM_BUSI     P0708            TS_SO_4M_06      25       64         0         0
    ZK            CM_BUSI     P0709            TS_SO_4M_05      25       64         0         0
    ZK            CM_BUSI     P0710            TS_SO_4M_04      25       64         0         0
    ZK            CM_BUSI     P0711            TS_SO_4M_03      25       64         0         0
    ZK            CM_BUSI     P0712            TS_SO_4M_02      25       64         0         0
    */

	--附2：表平均行长度算法：
	/*
    Row Format
    Row piece in a database block:

    Row flag(1) +  Lock byte(1) + # of cols(1) + Cluster key idx(1) +  Column length(1 or 3)            + Column data ...
    |<---- Row overhead --------------------->|                       |<-   0xFE(1) Length field(2)->|
                                                                            0xFF(NULL)

    This format is identical between version 8 and Oracle9i. This information is well documented.

    Row Format: Column Data
    ? Column data is stored as a series of column length
    values and column data pairs
    ? Extract from a logical block dump:

    tab 0, row 0, @0x6f
    tl: 6 fb: --H-FL-- lb: 0x0 cc: 1
    col 0: [ 2] c1 02
    tab 0, row 1, @0x6d6
    tl: 226 fb: --H-FL-- lb: 0x0 cc: 2
    col 0: [ 2] c1 03
    col 1: [219] 6e 6f 4b 4c 4d ...

    Flag byte(fb): H=header,
    F=first, L=last (entire row)
    Column count (cc) = 1,
    a NULL column in position 2
    Column length is 2 bytes,
    the data bytes are c1 03

    Column data is stored as a series of pairs of column lengths and the corresponding data.
    The column length is stored in one byte if the length is up to 250 bytes. A NULL value
    stored between two populated columns will be represented as 0xFF (literally) in the length byte.
    If the column is over 250 bytes long, three bytes are used to represent the length, the
    first byte being the value 0xFE and the next two bytes being the column length.
    Trailing NULLs are not stored. They occupy no space in the block.

    注：上述算法好像还是有约2％的误差。目前原因未知（by Luzp,070411）
    ref:
        1) 《Oracle DSI402e-Data Types and Block Structures.pdf》
    */

	--附3：计算块内的行数
	/*
    S1:
    公式：block size=
                BLOCK COMMON HEADER + TRANSACTION VARIABLE HEADER + TRANSACTION FIXED HEADER +
                DATA HEADER + Tail Field + table directory + row directory + (avg_row_len * x )/(1-pctfree/100)

    S2:
    block size                  =8192
    BLOCK COMMON HEADER         =20
    TRANSACTION VARIABLE HEADER =(24 * table initrans)
    TRANSACTION FIXED HEADER    =48
    DATA HEADER                 =14
    Tail Field                  =4
    table directory             =(4 * n ) --n:num of tables (n = 1 for non-clustered tables)
    row directory               = (2 * x)   --x:num of rows in the block
    table pctfree(%)            =??
    avg_row_len                 =??

    注：上述算法好像还是有约5％的误差。目前原因未知（by Luzp,070411）
    ref:
        1) 《Oracle DSI402e-Data Types and Block Structures.pdf》
        2) 《Oracle DSI401_Dumps,Crushes,and Corruptions.pdf》
        3) Oracle Metalink Doc ID:Note:10640.1 《Extent and Block Space Calculation and Usage in V7-V9 Database》
    */

