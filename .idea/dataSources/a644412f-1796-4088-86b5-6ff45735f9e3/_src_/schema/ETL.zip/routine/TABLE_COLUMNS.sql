create function table_columns(towner in varchar2,
                                             tname  in varchar2)
  return varchar2 as
  v_tmp   varchar2(3000);
  v_count number(20) := 0;
  v_num   number(20);
begin
  select count(*)
    into v_num
    from ALL_tab_columns
   where table_name = tname
     and owner = towner;
  for col in (select *
                from ALL_tab_columns
               where table_name = tname
                 and owner = towner
               order by column_id) loop
    v_tmp   := v_tmp || col.column_name;
    v_count := v_count + 1;
    if (v_count < v_num) then
      v_tmp := v_tmp || ',';
    end if;
  end loop;
  return v_tmp;
end table_columns;

