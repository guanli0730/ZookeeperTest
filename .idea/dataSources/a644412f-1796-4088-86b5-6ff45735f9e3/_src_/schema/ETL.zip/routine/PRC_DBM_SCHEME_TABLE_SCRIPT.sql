create procedure prc_dbm_scheme_table_script as

  type codetype is table of number index by pls_integer;
  codelist codetype;

  startyear number(10) := 2011;
  endyear   number(10) := 2013;

  startyear2 number(10) := 11;
  endyear2   number(10) := 13;

  drop_sql       varchar2(4000);
  create_sql     varchar2(4000);
  pk_sql         varchar2(4000);
  index1_sql     varchar2(4000);
  index2_sql     varchar2(4000);
  index3_sql     varchar2(4000);
  index4_sql     varchar2(4000);
  index5_sql     varchar2(4000);
  index6_sql     varchar2(4000);
  index7_sql     varchar2(4000);
  index8_sql     varchar2(4000);
  bat_table_name varchar2(100);
  owner          varchar2(100);

begin
  for mytab in (select * from DBM_SCHEME_TABLE where tactics = 'Y') loop
    for j in startyear .. endyear loop
      bat_table_name := mytab.table_name || '_' || j;

      drop_sql := 'drop table ' || mytab.table_owner || '.' ||
                  bat_table_name || ' cascade constraints;';

      create_sql := 'create table ' || mytab.table_owner || '.' ||
                    bat_table_name || ' (' || mytab.columns_name ||
                    ') tablespace ' || mytab.table_tablespace || ';';

      pk_sql := null;
      if (mytab.pk_names is not null and length(bat_table_name) <= 27) then
        pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                  bat_table_name || ' add constraint PK_' || bat_table_name ||
                  ' primary key (' || mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
      elsif (mytab.pk_names is not null and length(bat_table_name) > 27) then
        pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                  bat_table_name || ' add constraint PK_' ||
                  substr(bat_table_name, -27) || ' primary key (' ||
                  mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
      end if;

      index1_sql := null;
      if (mytab.index1 is not null and length(bat_table_name) <= 24) then
        index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_1 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index1 ||
                      ') tablespace ' || mytab.index1_tablespace || ';';
      elsif (mytab.index1 is not null and length(bat_table_name) > 24) then
        index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_1 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index1 || ') tablespace ' ||
                      mytab.index1_tablespace || ';';
      end if;

      index2_sql := null;
      if (mytab.index2 is not null and length(bat_table_name) <= 24) then
        index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_2 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index2 ||
                      ') tablespace ' || mytab.index2_tablespace || ';';
      elsif (mytab.index2 is not null and length(bat_table_name) > 24) then
        index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_2 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index2 || ') tablespace ' ||
                      mytab.index2_tablespace || ';';
      end if;

      index3_sql := null;
      if (mytab.index3 is not null and length(bat_table_name) <= 24) then
        index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_3 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index3 ||
                      ') tablespace ' || mytab.index3_tablespace || ';';
      elsif (mytab.index3 is not null and length(bat_table_name) > 24) then
        index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_3 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index3 || ') tablespace ' ||
                      mytab.index3_tablespace || ';';
      end if;

      index4_sql := null;
      if (mytab.index4 is not null and length(bat_table_name) <= 24) then
        index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_4 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index4 ||
                      ') tablespace ' || mytab.index4_tablespace || ';';
      elsif (mytab.index4 is not null and length(bat_table_name) > 24) then
        index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_4 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index4 || ') tablespace ' ||
                      mytab.index4_tablespace || ';';
      end if;

      index5_sql := null;
      if (mytab.index5 is not null and length(bat_table_name) <= 24) then
        index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_5 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index5 ||
                      ') tablespace ' || mytab.index5_tablespace || ';';
      elsif (mytab.index5 is not null and length(bat_table_name) > 24) then
        index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_5 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index5 || ') tablespace ' ||
                      mytab.index5_tablespace || ';';
      end if;

      index6_sql := null;
      if (mytab.index6 is not null and length(bat_table_name) <= 24) then
        index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_6 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index6 ||
                      ') tablespace ' || mytab.index6_tablespace || ';';
      elsif (mytab.index6 is not null and length(bat_table_name) > 24) then
        index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_6 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index6 || ') tablespace ' ||
                      mytab.index6_tablespace || ';';
      end if;

      index7_sql := null;
      if (mytab.index7 is not null and length(bat_table_name) <= 24) then
        index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_7 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index7 ||
                      ') tablespace ' || mytab.index7_tablespace || ';';
      elsif (mytab.index7 is not null and length(bat_table_name) > 24) then
        index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_7 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index7 || ') tablespace ' ||
                      mytab.index7_tablespace || ';';
      end if;

      index8_sql := null;
      if (mytab.index8 is not null and length(bat_table_name) <= 24) then
        index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_8 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index8 ||
                      ') tablespace ' || mytab.index8_tablespace || ';';
      elsif (mytab.index8 is not null and length(bat_table_name) > 24) then
        index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_8 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index8 || ') tablespace ' ||
                      mytab.index8_tablespace || ';';
      end if;

      begin
        insert into dbm_scheme_table_script
        values
          (mytab.table_owner,
           bat_table_name,
           drop_sql,
           create_sql,
           pk_sql,
           index1_sql,
           index2_sql,
           index3_sql,
           index4_sql,
           index5_sql,
           index6_sql,
           index7_sql,
           index8_sql,
           sysdate);
        commit;
      exception
        when others then
          rollback;
      end;
    end loop;
  end loop;

  for mytab in (select * from DBM_SCHEME_TABLE where tactics = 'YM') loop
    for j in startyear .. endyear loop
      for k in 1 .. 12 loop
        bat_table_name := mytab.table_name || '_' || j || lpad(k, 2, 0);

        drop_sql := 'drop table ' || mytab.table_owner || '.' ||
                    bat_table_name || ' cascade constraints;';

        create_sql := 'create table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.columns_name ||
                      ') tablespace ' || mytab.table_tablespace || ';';

        pk_sql := null;
        if (mytab.pk_names is not null and length(bat_table_name) <= 27) then
          pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                    bat_table_name || ' add constraint PK_' ||
                    bat_table_name || ' primary key (' || mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
        elsif (mytab.pk_names is not null and length(bat_table_name) > 27) then
          pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                    bat_table_name || ' add constraint PK_' ||
                    substr(bat_table_name, -27) || ' primary key (' ||
                    mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
        end if;

        index1_sql := null;
        if (mytab.index1 is not null and length(bat_table_name) <= 24) then
          index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_1 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index1 ||
                        ') tablespace ' || mytab.index1_tablespace || ';';
        elsif (mytab.index1 is not null and length(bat_table_name) > 24) then
          index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_1 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index1 || ') tablespace ' ||
                        mytab.index1_tablespace || ';';
        end if;

        index2_sql := null;
        if (mytab.index2 is not null and length(bat_table_name) <= 24) then
          index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_2 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index2 ||
                        ') tablespace ' || mytab.index2_tablespace || ';';
        elsif (mytab.index2 is not null and length(bat_table_name) > 24) then
          index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_2 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index2 || ') tablespace ' ||
                        mytab.index2_tablespace || ';';
        end if;

        index3_sql := null;
        if (mytab.index3 is not null and length(bat_table_name) <= 24) then
          index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_3 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index3 ||
                        ') tablespace ' || mytab.index3_tablespace || ';';
        elsif (mytab.index3 is not null and length(bat_table_name) > 24) then
          index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_3 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index3 || ') tablespace ' ||
                        mytab.index3_tablespace || ';';
        end if;

        index4_sql := null;
        if (mytab.index4 is not null and length(bat_table_name) <= 24) then
          index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_4 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index4 ||
                        ') tablespace ' || mytab.index4_tablespace || ';';
        elsif (mytab.index4 is not null and length(bat_table_name) > 24) then
          index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_4 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index4 || ') tablespace ' ||
                        mytab.index4_tablespace || ';';
        end if;

        index5_sql := null;
        if (mytab.index5 is not null and length(bat_table_name) <= 24) then
          index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_5 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index5 ||
                        ') tablespace ' || mytab.index5_tablespace || ';';
        elsif (mytab.index5 is not null and length(bat_table_name) > 24) then
          index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_5 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index5 || ') tablespace ' ||
                        mytab.index5_tablespace || ';';
        end if;

        index6_sql := null;
        if (mytab.index6 is not null and length(bat_table_name) <= 24) then
          index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_6 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index6 ||
                        ') tablespace ' || mytab.index6_tablespace || ';';
        elsif (mytab.index6 is not null and length(bat_table_name) > 24) then
          index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_6 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index6 || ') tablespace ' ||
                        mytab.index6_tablespace || ';';
        end if;

        index7_sql := null;
        if (mytab.index7 is not null and length(bat_table_name) <= 24) then
          index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_7 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index7 ||
                        ') tablespace ' || mytab.index7_tablespace || ';';
        elsif (mytab.index7 is not null and length(bat_table_name) > 24) then
          index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_7 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index7 || ') tablespace ' ||
                        mytab.index7_tablespace || ';';
        end if;

        index8_sql := null;
        if (mytab.index8 is not null and length(bat_table_name) <= 24) then
          index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_8 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index8 ||
                        ') tablespace ' || mytab.index8_tablespace || ';';
        elsif (mytab.index8 is not null and length(bat_table_name) > 24) then
          index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_8 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index8 || ') tablespace ' ||
                        mytab.index8_tablespace || ';';
        end if;

        begin
          insert into dbm_scheme_table_script
          values
            (mytab.table_owner,
             bat_table_name,
             drop_sql,
             create_sql,
             pk_sql,
             index1_sql,
             index2_sql,
             index3_sql,
             index4_sql,
             index5_sql,
             index6_sql,
             index7_sql,
             index8_sql,
             sysdate);
          commit;
        exception
          when others then
            rollback;
        end;
      end loop;
    end loop;
  end loop;

  for mytab in (select * from DBM_SCHEME_TABLE where tactics = 'RYM') loop
    select mytab.table_owner into owner from dual;
    if (owner = 'SO1') then
      codelist(1) := 210;
      codelist(2) := 211;
      codelist(3) := 212;
      codelist(4) := 213;
      codelist(5) := 214;
    elsif (owner = 'SO2') then
      codelist(1) := 215;
      codelist(2) := 216;
      codelist(3) := 217;
      codelist(4) := 218;
      codelist(5) := 219;
    else
      codelist(1) := 210;
      codelist(2) := 211;
      codelist(3) := 212;
      codelist(4) := 213;
      codelist(5) := 214;
      codelist(6) := 215;
      codelist(7) := 216;
      codelist(8) := 217;
      codelist(9) := 218;
      codelist(10) := 219;
    end if;
    for i in codelist.first .. codelist.last loop
      for j in startyear .. endyear loop
        for k in 1 .. 12 loop
          bat_table_name := mytab.table_name || '_' || codelist(i) || '_' || j ||
                            lpad(k, 2, 0);

          drop_sql := 'drop table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' cascade constraints;';

          create_sql := 'create table ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.columns_name ||
                        ') tablespace ' || mytab.table_tablespace || ';';

          pk_sql := null;
          if (mytab.pk_names is not null and length(bat_table_name) <= 27) then
            pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' add constraint PK_' ||
                      bat_table_name || ' primary key (' || mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
          elsif (mytab.pk_names is not null and length(bat_table_name) > 27) then
            pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' add constraint PK_' ||
                      substr(bat_table_name, -27) || ' primary key (' ||
                      mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
          end if;

          index1_sql := null;
          if (mytab.index1 is not null and length(bat_table_name) <= 24) then
            index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_1 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index1 ||
                          ') tablespace ' || mytab.index1_tablespace || ';';
          elsif (mytab.index1 is not null and length(bat_table_name) > 24) then
            index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_1 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index1 || ') tablespace ' ||
                          mytab.index1_tablespace || ';';
          end if;

          index2_sql := null;
          if (mytab.index2 is not null and length(bat_table_name) <= 24) then
            index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_2 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index2 ||
                          ') tablespace ' || mytab.index2_tablespace || ';';
          elsif (mytab.index2 is not null and length(bat_table_name) > 24) then
            index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_2 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index2 || ') tablespace ' ||
                          mytab.index2_tablespace || ';';
          end if;

          index3_sql := null;
          if (mytab.index3 is not null and length(bat_table_name) <= 24) then
            index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_3 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index3 ||
                          ') tablespace ' || mytab.index3_tablespace || ';';
          elsif (mytab.index3 is not null and length(bat_table_name) > 24) then
            index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_3 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index3 || ') tablespace ' ||
                          mytab.index3_tablespace || ';';
          end if;

          index4_sql := null;
          if (mytab.index4 is not null and length(bat_table_name) <= 24) then
            index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_4 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index4 ||
                          ') tablespace ' || mytab.index4_tablespace || ';';
          elsif (mytab.index4 is not null and length(bat_table_name) > 24) then
            index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_4 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index4 || ') tablespace ' ||
                          mytab.index4_tablespace || ';';
          end if;

          index5_sql := null;
          if (mytab.index5 is not null and length(bat_table_name) <= 24) then
            index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_5 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index5 ||
                          ') tablespace ' || mytab.index5_tablespace || ';';
          elsif (mytab.index5 is not null and length(bat_table_name) > 24) then
            index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_5 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index5 || ') tablespace ' ||
                          mytab.index5_tablespace || ';';
          end if;

          index6_sql := null;
          if (mytab.index6 is not null and length(bat_table_name) <= 24) then
            index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_6 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index6 ||
                          ') tablespace ' || mytab.index6_tablespace || ';';
          elsif (mytab.index6 is not null and length(bat_table_name) > 24) then
            index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_6 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index6 || ') tablespace ' ||
                          mytab.index6_tablespace || ';';
          end if;

          index7_sql := null;
          if (mytab.index7 is not null and length(bat_table_name) <= 24) then
            index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_7 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index7 ||
                          ') tablespace ' || mytab.index7_tablespace || ';';
          elsif (mytab.index7 is not null and length(bat_table_name) > 24) then
            index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_7 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index7 || ') tablespace ' ||
                          mytab.index7_tablespace || ';';
          end if;

          index8_sql := null;
          if (mytab.index8 is not null and length(bat_table_name) <= 24) then
            index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_8 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index8 ||
                          ') tablespace ' || mytab.index8_tablespace || ';';
          elsif (mytab.index8 is not null and length(bat_table_name) > 24) then
            index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_8 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index8 || ') tablespace ' ||
                          mytab.index8_tablespace || ';';
          end if;

          begin
            insert into dbm_scheme_table_script
            values
              (mytab.table_owner,
               bat_table_name,
               drop_sql,
               create_sql,
               pk_sql,
               index1_sql,
               index2_sql,
               index3_sql,
               index4_sql,
               index5_sql,
               index6_sql,
               index7_sql,
               index8_sql,
               sysdate);
            commit;
          exception
            when others then
              rollback;
          end;
        end loop;
      end loop;

    end loop;
  end loop;

  for mytab in (select * from DBM_SCHEME_TABLE where tactics = 'R') loop
    select mytab.table_owner into owner from dual;
    if (owner = 'SO1') then
      codelist(1) := 210;
      codelist(2) := 211;
      codelist(3) := 212;
      codelist(4) := 213;
      codelist(5) := 214;
    elsif (owner = 'SO2') then
      codelist(1) := 215;
      codelist(2) := 216;
      codelist(3) := 217;
      codelist(4) := 218;
      codelist(5) := 219;
    else
      codelist(1) := 210;
      codelist(2) := 211;
      codelist(3) := 212;
      codelist(4) := 213;
      codelist(5) := 214;
      codelist(6) := 215;
      codelist(7) := 216;
      codelist(8) := 217;
      codelist(9) := 218;
      codelist(10) := 219;
    end if;
    for i in codelist.first .. codelist.last loop
      bat_table_name := mytab.table_name || '_' || codelist(i);

      drop_sql := 'drop table ' || mytab.table_owner || '.' ||
                  bat_table_name || ' cascade constraints;';

      create_sql := 'create table ' || mytab.table_owner || '.' ||
                    bat_table_name || ' (' || mytab.columns_name ||
                    ') tablespace ' || mytab.table_tablespace || ';';
      pk_sql     := null;
      if (mytab.pk_names is not null and length(bat_table_name) <= 27) then
        pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                  bat_table_name || ' add constraint PK_' || bat_table_name ||
                  ' primary key (' || mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
      elsif (mytab.pk_names is not null and length(bat_table_name) > 27) then
        pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                  bat_table_name || ' add constraint PK_' ||
                  substr(bat_table_name, -27) || ' primary key (' ||
                  mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
      end if;

      index1_sql := null;
      if (mytab.index1 is not null and length(bat_table_name) <= 24) then
        index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_1 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index1 ||
                      ') tablespace ' || mytab.index1_tablespace || ';';
      elsif (mytab.index1 is not null and length(bat_table_name) > 24) then
        index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_1 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index1 || ') tablespace ' ||
                      mytab.index1_tablespace || ';';
      end if;

      index2_sql := null;
      if (mytab.index2 is not null and length(bat_table_name) <= 24) then
        index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_2 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index2 ||
                      ') tablespace ' || mytab.index2_tablespace || ';';
      elsif (mytab.index2 is not null and length(bat_table_name) > 24) then
        index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_2 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index2 || ') tablespace ' ||
                      mytab.index2_tablespace || ';';
      end if;

      index3_sql := null;
      if (mytab.index3 is not null and length(bat_table_name) <= 24) then
        index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_3 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index3 ||
                      ') tablespace ' || mytab.index3_tablespace || ';';
      elsif (mytab.index3 is not null and length(bat_table_name) > 24) then
        index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_3 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index3 || ') tablespace ' ||
                      mytab.index3_tablespace || ';';
      end if;

      index4_sql := null;
      if (mytab.index4 is not null and length(bat_table_name) <= 24) then
        index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_4 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index4 ||
                      ') tablespace ' || mytab.index4_tablespace || ';';
      elsif (mytab.index4 is not null and length(bat_table_name) > 24) then
        index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_4 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index4 || ') tablespace ' ||
                      mytab.index4_tablespace || ';';
      end if;

      index5_sql := null;
      if (mytab.index5 is not null and length(bat_table_name) <= 24) then
        index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_5 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index5 ||
                      ') tablespace ' || mytab.index5_tablespace || ';';
      elsif (mytab.index5 is not null and length(bat_table_name) > 24) then
        index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_5 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index5 || ') tablespace ' ||
                      mytab.index5_tablespace || ';';
      end if;

      index6_sql := null;
      if (mytab.index6 is not null and length(bat_table_name) <= 24) then
        index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_6 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index6 ||
                      ') tablespace ' || mytab.index6_tablespace || ';';
      elsif (mytab.index6 is not null and length(bat_table_name) > 24) then
        index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_6 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index6 || ') tablespace ' ||
                      mytab.index6_tablespace || ';';
      end if;

      index7_sql := null;
      if (mytab.index7 is not null and length(bat_table_name) <= 24) then
        index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_7 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index7 ||
                      ') tablespace ' || mytab.index7_tablespace || ';';
      elsif (mytab.index7 is not null and length(bat_table_name) > 24) then
        index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_7 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index7 || ') tablespace ' ||
                      mytab.index7_tablespace || ';';
      end if;

      index8_sql := null;
      if (mytab.index8 is not null and length(bat_table_name) <= 24) then
        index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_8 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index8 ||
                      ') tablespace ' || mytab.index8_tablespace || ';';
      elsif (mytab.index8 is not null and length(bat_table_name) > 24) then
        index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_8 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index8 || ') tablespace ' ||
                      mytab.index8_tablespace || ';';
      end if;

      begin
        insert into dbm_scheme_table_script
        values
          (mytab.table_owner,
           bat_table_name,
           drop_sql,
           create_sql,
           pk_sql,
           index1_sql,
           index2_sql,
           index3_sql,
           index4_sql,
           index5_sql,
           index6_sql,
           index7_sql,
           index8_sql,
           sysdate);
        commit;
      exception
        when others then
          rollback;
      end;
    end loop;
  end loop;

  for mytab in (select * from DBM_SCHEME_TABLE where tactics = 'RE') loop
    select mytab.table_owner into owner from dual;
    if (owner = 'SO1') then
      codelist(1) := 210;
      codelist(2) := 211;
      codelist(3) := 212;
      codelist(4) := 213;
      codelist(5) := 214;
    elsif (owner = 'SO2') then
      codelist(1) := 215;
      codelist(2) := 216;
      codelist(3) := 217;
      codelist(4) := 218;
      codelist(5) := 219;
    else
      codelist(1) := 210;
      codelist(2) := 211;
      codelist(3) := 212;
      codelist(4) := 213;
      codelist(5) := 214;
      codelist(6) := 215;
      codelist(7) := 216;
      codelist(8) := 217;
      codelist(9) := 218;
      codelist(10) := 219;
    end if;
    for i in codelist.first .. codelist.last loop
      bat_table_name := substr(mytab.table_name,
                               0,
                               length(mytab.table_name) - 4) || '_' ||
                        codelist(i) || '_ERR';

      drop_sql := 'drop table ' || mytab.table_owner || '.' ||
                  bat_table_name || ' cascade constraints;';

      create_sql := 'create table ' || mytab.table_owner || '.' ||
                    bat_table_name || ' (' || mytab.columns_name ||
                    ') tablespace ' || mytab.table_tablespace || ';';
      pk_sql     := null;
      if (mytab.pk_names is not null and length(bat_table_name) <= 27) then
        pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                  bat_table_name || ' add constraint PK_' || bat_table_name ||
                  ' primary key (' || mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
      elsif (mytab.pk_names is not null and length(bat_table_name) > 27) then
        pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                  bat_table_name || ' add constraint PK_' ||
                  substr(bat_table_name, -27) || ' primary key (' ||
                  mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
      end if;

      index1_sql := null;
      if (mytab.index1 is not null and length(bat_table_name) <= 24) then
        index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_1 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index1 ||
                      ') tablespace ' || mytab.index1_tablespace || ';';
      elsif (mytab.index1 is not null and length(bat_table_name) > 24) then
        index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_1 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index1 || ') tablespace ' ||
                      mytab.index1_tablespace || ';';
      end if;

      index2_sql := null;
      if (mytab.index2 is not null and length(bat_table_name) <= 24) then
        index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_2 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index2 ||
                      ') tablespace ' || mytab.index2_tablespace || ';';
      elsif (mytab.index2 is not null and length(bat_table_name) > 24) then
        index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_2 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index2 || ') tablespace ' ||
                      mytab.index2_tablespace || ';';
      end if;

      index3_sql := null;
      if (mytab.index3 is not null and length(bat_table_name) <= 24) then
        index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_3 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index3 ||
                      ') tablespace ' || mytab.index3_tablespace || ';';
      elsif (mytab.index3 is not null and length(bat_table_name) > 24) then
        index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_3 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index3 || ') tablespace ' ||
                      mytab.index3_tablespace || ';';
      end if;

      index4_sql := null;
      if (mytab.index4 is not null and length(bat_table_name) <= 24) then
        index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_4 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index4 ||
                      ') tablespace ' || mytab.index4_tablespace || ';';
      elsif (mytab.index4 is not null and length(bat_table_name) > 24) then
        index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_4 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index4 || ') tablespace ' ||
                      mytab.index4_tablespace || ';';
      end if;

      index5_sql := null;
      if (mytab.index5 is not null and length(bat_table_name) <= 24) then
        index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_5 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index5 ||
                      ') tablespace ' || mytab.index5_tablespace || ';';
      elsif (mytab.index5 is not null and length(bat_table_name) > 24) then
        index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_5 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index5 || ') tablespace ' ||
                      mytab.index5_tablespace || ';';
      end if;

      index6_sql := null;
      if (mytab.index6 is not null and length(bat_table_name) <= 24) then
        index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_6 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index6 ||
                      ') tablespace ' || mytab.index6_tablespace || ';';
      elsif (mytab.index6 is not null and length(bat_table_name) > 24) then
        index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_6 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index6 || ') tablespace ' ||
                      mytab.index6_tablespace || ';';
      end if;

      index7_sql := null;
      if (mytab.index7 is not null and length(bat_table_name) <= 24) then
        index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_7 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index7 ||
                      ') tablespace ' || mytab.index7_tablespace || ';';
      elsif (mytab.index7 is not null and length(bat_table_name) > 24) then
        index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_7 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index7 || ') tablespace ' ||
                      mytab.index7_tablespace || ';';
      end if;

      index8_sql := null;
      if (mytab.index8 is not null and length(bat_table_name) <= 24) then
        index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      bat_table_name || '_8 on ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.index8 ||
                      ') tablespace ' || mytab.index8_tablespace || ';';
      elsif (mytab.index8 is not null and length(bat_table_name) > 24) then
        index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                      substr(bat_table_name, -24) || '_8 on ' ||
                      mytab.table_owner || '.' || bat_table_name || ' (' ||
                      mytab.index8 || ') tablespace ' ||
                      mytab.index8_tablespace || ';';
      end if;

      begin
        insert into dbm_scheme_table_script
        values
          (mytab.table_owner,
           bat_table_name,
           drop_sql,
           create_sql,
           pk_sql,
           index1_sql,
           index2_sql,
           index3_sql,
           index4_sql,
           index5_sql,
           index6_sql,
           index7_sql,
           index8_sql,
           sysdate);
        commit;
      exception
        when others then
          rollback;
      end;
    end loop;
  end loop;

  for mytab in (select * from DBM_SCHEME_TABLE where tactics = 'RYME') loop
    select mytab.table_owner into owner from dual;
    if (owner = 'SO1') then
      codelist(1) := 210;
      codelist(2) := 211;
      codelist(3) := 212;
      codelist(4) := 213;
      codelist(5) := 214;
    elsif (owner = 'SO2') then
      codelist(1) := 215;
      codelist(2) := 216;
      codelist(3) := 217;
      codelist(4) := 218;
      codelist(5) := 219;
    else
      codelist(1) := 210;
      codelist(2) := 211;
      codelist(3) := 212;
      codelist(4) := 213;
      codelist(5) := 214;
      codelist(6) := 215;
      codelist(7) := 216;
      codelist(8) := 217;
      codelist(9) := 218;
      codelist(10) := 219;
    end if;
    for i in codelist.first .. codelist.last loop
      for j in startyear .. endyear loop
        for k in 1 .. 12 loop
          bat_table_name := substr(mytab.table_name,
                               0,
                               length(mytab.table_name) - 4) || '_' || codelist(i) || '_' || j ||
                            lpad(k, 2, 0)||'_ERR';

          drop_sql := 'drop table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' cascade constraints;';

          create_sql := 'create table ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.columns_name ||
                        ') tablespace ' || mytab.table_tablespace || ';';

          pk_sql := null;
          if (mytab.pk_names is not null and length(bat_table_name) <= 27) then
            pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' add constraint PK_' ||
                      bat_table_name || ' primary key (' || mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
          elsif (mytab.pk_names is not null and length(bat_table_name) > 27) then
            pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' add constraint PK_' ||
                      substr(bat_table_name, -27) || ' primary key (' ||
                      mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
          end if;

          index1_sql := null;
          if (mytab.index1 is not null and length(bat_table_name) <= 24) then
            index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_1 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index1 ||
                          ') tablespace ' || mytab.index1_tablespace || ';';
          elsif (mytab.index1 is not null and length(bat_table_name) > 24) then
            index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_1 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index1 || ') tablespace ' ||
                          mytab.index1_tablespace || ';';
          end if;

          index2_sql := null;
          if (mytab.index2 is not null and length(bat_table_name) <= 24) then
            index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_2 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index2 ||
                          ') tablespace ' || mytab.index2_tablespace || ';';
          elsif (mytab.index2 is not null and length(bat_table_name) > 24) then
            index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_2 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index2 || ') tablespace ' ||
                          mytab.index2_tablespace || ';';
          end if;

          index3_sql := null;
          if (mytab.index3 is not null and length(bat_table_name) <= 24) then
            index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_3 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index3 ||
                          ') tablespace ' || mytab.index3_tablespace || ';';
          elsif (mytab.index3 is not null and length(bat_table_name) > 24) then
            index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_3 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index3 || ') tablespace ' ||
                          mytab.index3_tablespace || ';';
          end if;

          index4_sql := null;
          if (mytab.index4 is not null and length(bat_table_name) <= 24) then
            index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_4 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index4 ||
                          ') tablespace ' || mytab.index4_tablespace || ';';
          elsif (mytab.index4 is not null and length(bat_table_name) > 24) then
            index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_4 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index4 || ') tablespace ' ||
                          mytab.index4_tablespace || ';';
          end if;

          index5_sql := null;
          if (mytab.index5 is not null and length(bat_table_name) <= 24) then
            index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_5 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index5 ||
                          ') tablespace ' || mytab.index5_tablespace || ';';
          elsif (mytab.index5 is not null and length(bat_table_name) > 24) then
            index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_5 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index5 || ') tablespace ' ||
                          mytab.index5_tablespace || ';';
          end if;

          index6_sql := null;
          if (mytab.index6 is not null and length(bat_table_name) <= 24) then
            index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_6 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index6 ||
                          ') tablespace ' || mytab.index6_tablespace || ';';
          elsif (mytab.index6 is not null and length(bat_table_name) > 24) then
            index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_6 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index6 || ') tablespace ' ||
                          mytab.index6_tablespace || ';';
          end if;

          index7_sql := null;
          if (mytab.index7 is not null and length(bat_table_name) <= 24) then
            index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_7 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index7 ||
                          ') tablespace ' || mytab.index7_tablespace || ';';
          elsif (mytab.index7 is not null and length(bat_table_name) > 24) then
            index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_7 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index7 || ') tablespace ' ||
                          mytab.index7_tablespace || ';';
          end if;

          index8_sql := null;
          if (mytab.index8 is not null and length(bat_table_name) <= 24) then
            index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_8 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index8 ||
                          ') tablespace ' || mytab.index8_tablespace || ';';
          elsif (mytab.index8 is not null and length(bat_table_name) > 24) then
            index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_8 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index8 || ') tablespace ' ||
                          mytab.index8_tablespace || ';';
          end if;

          begin
            insert into dbm_scheme_table_script
            values
              (mytab.table_owner,
               bat_table_name,
               drop_sql,
               create_sql,
               pk_sql,
               index1_sql,
               index2_sql,
               index3_sql,
               index4_sql,
               index5_sql,
               index6_sql,
               index7_sql,
               index8_sql,
               sysdate);
            commit;
          exception
            when others then
              rollback;
          end;
        end loop;
      end loop;

    end loop;
  end loop;

  for mytab in (select * from DBM_SCHEME_TABLE where tactics = 'REYM4') loop
    select mytab.table_owner into owner from dual;
    if (owner = 'SO1') then
      codelist(1) := 210;
      codelist(2) := 211;
      codelist(3) := 212;
      codelist(4) := 213;
      codelist(5) := 214;
    elsif (owner = 'SO2') then
      codelist(1) := 215;
      codelist(2) := 216;
      codelist(3) := 217;
      codelist(4) := 218;
      codelist(5) := 219;
    else
      codelist(1) := 210;
      codelist(2) := 211;
      codelist(3) := 212;
      codelist(4) := 213;
      codelist(5) := 214;
      codelist(6) := 215;
      codelist(7) := 216;
      codelist(8) := 217;
      codelist(9) := 218;
      codelist(10) := 219;
    end if;
    for i in codelist.first .. codelist.last loop
      for j in startyear2 .. endyear2 loop
        for k in 1 .. 12 loop
          bat_table_name := substr(mytab.table_name,
                                   0,
                                   length(mytab.table_name) - 4) || '_' ||
                            codelist(i) || '_ERR_' || j || lpad(k, 2, 0);

          drop_sql := 'drop table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' cascade constraints;';

          create_sql := 'create table ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.columns_name ||
                        ') tablespace ' || mytab.table_tablespace || ';';

          pk_sql := null;
          if (mytab.pk_names is not null and length(bat_table_name) <= 27) then
            pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' add constraint PK_' ||
                      bat_table_name || ' primary key (' || mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
          elsif (mytab.pk_names is not null and length(bat_table_name) > 27) then
            pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' add constraint PK_' ||
                      substr(bat_table_name, -27) || ' primary key (' ||
                      mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
          end if;

          index1_sql := null;
          if (mytab.index1 is not null and length(bat_table_name) <= 24) then
            index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_1 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index1 ||
                          ') tablespace ' || mytab.index1_tablespace || ';';
          elsif (mytab.index1 is not null and length(bat_table_name) > 24) then
            index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_1 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index1 || ') tablespace ' ||
                          mytab.index1_tablespace || ';';
          end if;

          index2_sql := null;
          if (mytab.index2 is not null and length(bat_table_name) <= 24) then
            index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_2 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index2 ||
                          ') tablespace ' || mytab.index2_tablespace || ';';
          elsif (mytab.index2 is not null and length(bat_table_name) > 24) then
            index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_2 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index2 || ') tablespace ' ||
                          mytab.index2_tablespace || ';';
          end if;

          index3_sql := null;
          if (mytab.index3 is not null and length(bat_table_name) <= 24) then
            index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_3 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index3 ||
                          ') tablespace ' || mytab.index3_tablespace || ';';
          elsif (mytab.index3 is not null and length(bat_table_name) > 24) then
            index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_3 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index3 || ') tablespace ' ||
                          mytab.index3_tablespace || ';';
          end if;

          index4_sql := null;
          if (mytab.index4 is not null and length(bat_table_name) <= 24) then
            index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_4 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index4 ||
                          ') tablespace ' || mytab.index4_tablespace || ';';
          elsif (mytab.index4 is not null and length(bat_table_name) > 24) then
            index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_4 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index4 || ') tablespace ' ||
                          mytab.index4_tablespace || ';';
          end if;

          index5_sql := null;
          if (mytab.index5 is not null and length(bat_table_name) <= 24) then
            index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_5 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index5 ||
                          ') tablespace ' || mytab.index5_tablespace || ';';
          elsif (mytab.index5 is not null and length(bat_table_name) > 24) then
            index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_5 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index5 || ') tablespace ' ||
                          mytab.index5_tablespace || ';';
          end if;

          index6_sql := null;
          if (mytab.index6 is not null and length(bat_table_name) <= 24) then
            index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_6 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index6 ||
                          ') tablespace ' || mytab.index6_tablespace || ';';
          elsif (mytab.index6 is not null and length(bat_table_name) > 24) then
            index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_6 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index6 || ') tablespace ' ||
                          mytab.index6_tablespace || ';';
          end if;

          index7_sql := null;
          if (mytab.index7 is not null and length(bat_table_name) <= 24) then
            index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_7 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index7 ||
                          ') tablespace ' || mytab.index7_tablespace || ';';
          elsif (mytab.index7 is not null and length(bat_table_name) > 24) then
            index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_7 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index7 || ') tablespace ' ||
                          mytab.index7_tablespace || ';';
          end if;

          index8_sql := null;
          if (mytab.index8 is not null and length(bat_table_name) <= 24) then
            index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_8 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index8 ||
                          ') tablespace ' || mytab.index8_tablespace || ';';
          elsif (mytab.index8 is not null and length(bat_table_name) > 24) then
            index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_8 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index8 || ') tablespace ' ||
                          mytab.index8_tablespace || ';';
          end if;

          begin
            insert into dbm_scheme_table_script
            values
              (mytab.table_owner,
               bat_table_name,
               drop_sql,
               create_sql,
               pk_sql,
               index1_sql,
               index2_sql,
               index3_sql,
               index4_sql,
               index5_sql,
               index6_sql,
               index7_sql,
               index8_sql,
               sysdate);
            commit;
          exception
            when others then
              rollback;
          end;
        end loop;
      end loop;

    end loop;
  end loop;

  for mytab in (select * from DBM_SCHEME_TABLE where tactics = 'YM4') loop
    for j in startyear2 .. endyear2 loop
      for k in 1 .. 12 loop
        bat_table_name := mytab.table_name || '_' || j || lpad(k, 2, 0);

        drop_sql := 'drop table ' || mytab.table_owner || '.' ||
                    bat_table_name || ' cascade constraints;';

        create_sql := 'create table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.columns_name ||
                      ') tablespace ' || mytab.table_tablespace || ';';

        pk_sql := null;
        if (mytab.pk_names is not null and length(bat_table_name) <= 27) then
          pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                    bat_table_name || ' add constraint PK_' ||
                    bat_table_name || ' primary key (' || mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
        elsif (mytab.pk_names is not null and length(bat_table_name) > 27) then
          pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                    bat_table_name || ' add constraint PK_' ||
                    substr(bat_table_name, -27) || ' primary key (' ||
                    mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
        end if;

        index1_sql := null;
        if (mytab.index1 is not null and length(bat_table_name) <= 24) then
          index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_1 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index1 ||
                        ') tablespace ' || mytab.index1_tablespace || ';';
        elsif (mytab.index1 is not null and length(bat_table_name) > 24) then
          index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_1 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index1 || ') tablespace ' ||
                        mytab.index1_tablespace || ';';
        end if;

        index2_sql := null;
        if (mytab.index2 is not null and length(bat_table_name) <= 24) then
          index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_2 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index2 ||
                        ') tablespace ' || mytab.index2_tablespace || ';';
        elsif (mytab.index2 is not null and length(bat_table_name) > 24) then
          index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_2 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index2 || ') tablespace ' ||
                        mytab.index2_tablespace || ';';
        end if;

        index3_sql := null;
        if (mytab.index3 is not null and length(bat_table_name) <= 24) then
          index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_3 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index3 ||
                        ') tablespace ' || mytab.index3_tablespace || ';';
        elsif (mytab.index3 is not null and length(bat_table_name) > 24) then
          index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_3 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index3 || ') tablespace ' ||
                        mytab.index3_tablespace || ';';
        end if;

        index4_sql := null;
        if (mytab.index4 is not null and length(bat_table_name) <= 24) then
          index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_4 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index4 ||
                        ') tablespace ' || mytab.index4_tablespace || ';';
        elsif (mytab.index4 is not null and length(bat_table_name) > 24) then
          index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_4 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index4 || ') tablespace ' ||
                        mytab.index4_tablespace || ';';
        end if;

        index5_sql := null;
        if (mytab.index5 is not null and length(bat_table_name) <= 24) then
          index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_5 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index5 ||
                        ') tablespace ' || mytab.index5_tablespace || ';';
        elsif (mytab.index5 is not null and length(bat_table_name) > 24) then
          index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_5 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index5 || ') tablespace ' ||
                        mytab.index5_tablespace || ';';
        end if;

        index6_sql := null;
        if (mytab.index6 is not null and length(bat_table_name) <= 24) then
          index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_6 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index6 ||
                        ') tablespace ' || mytab.index6_tablespace || ';';
        elsif (mytab.index6 is not null and length(bat_table_name) > 24) then
          index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_6 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index6 || ') tablespace ' ||
                        mytab.index6_tablespace || ';';
        end if;

        index7_sql := null;
        if (mytab.index7 is not null and length(bat_table_name) <= 24) then
          index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_7 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index7 ||
                        ') tablespace ' || mytab.index7_tablespace || ';';
        elsif (mytab.index7 is not null and length(bat_table_name) > 24) then
          index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_7 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index7 || ') tablespace ' ||
                        mytab.index7_tablespace || ';';
        end if;

        index8_sql := null;
        if (mytab.index8 is not null and length(bat_table_name) <= 24) then
          index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_8 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index8 ||
                        ') tablespace ' || mytab.index8_tablespace || ';';
        elsif (mytab.index8 is not null and length(bat_table_name) > 24) then
          index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_8 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index8 || ') tablespace ' ||
                        mytab.index8_tablespace || ';';
        end if;

        begin
          insert into dbm_scheme_table_script
          values
            (mytab.table_owner,
             bat_table_name,
             drop_sql,
             create_sql,
             pk_sql,
             index1_sql,
             index2_sql,
             index3_sql,
             index4_sql,
             index5_sql,
             index6_sql,
             index7_sql,
             index8_sql,
             sysdate);
          commit;
        exception
          when others then
            rollback;
        end;
      end loop;
    end loop;
  end loop;

  for mytab in (select * from DBM_SCHEME_TABLE where tactics = 'YME') loop
    for j in startyear .. endyear loop
      for k in 1 .. 12 loop
        bat_table_name := substr(mytab.table_name,0,length(mytab.table_name) - 4) || '_' || j || lpad(k, 2, 0)|| '_ERR';

        drop_sql := 'drop table ' || mytab.table_owner || '.' ||
                    bat_table_name || ' cascade constraints;';

        create_sql := 'create table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' (' || mytab.columns_name ||
                      ') tablespace ' || mytab.table_tablespace || ';';

        pk_sql := null;
        if (mytab.pk_names is not null and length(bat_table_name) <= 27) then
          pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                    bat_table_name || ' add constraint PK_' ||
                    bat_table_name || ' primary key (' || mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
        elsif (mytab.pk_names is not null and length(bat_table_name) > 27) then
          pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                    bat_table_name || ' add constraint PK_' ||
                    substr(bat_table_name, -27) || ' primary key (' ||
                    mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
        end if;

        index1_sql := null;
        if (mytab.index1 is not null and length(bat_table_name) <= 24) then
          index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_1 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index1 ||
                        ') tablespace ' || mytab.index1_tablespace || ';';
        elsif (mytab.index1 is not null and length(bat_table_name) > 24) then
          index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_1 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index1 || ') tablespace ' ||
                        mytab.index1_tablespace || ';';
        end if;

        index2_sql := null;
        if (mytab.index2 is not null and length(bat_table_name) <= 24) then
          index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_2 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index2 ||
                        ') tablespace ' || mytab.index2_tablespace || ';';
        elsif (mytab.index2 is not null and length(bat_table_name) > 24) then
          index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_2 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index2 || ') tablespace ' ||
                        mytab.index2_tablespace || ';';
        end if;

        index3_sql := null;
        if (mytab.index3 is not null and length(bat_table_name) <= 24) then
          index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_3 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index3 ||
                        ') tablespace ' || mytab.index3_tablespace || ';';
        elsif (mytab.index3 is not null and length(bat_table_name) > 24) then
          index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_3 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index3 || ') tablespace ' ||
                        mytab.index3_tablespace || ';';
        end if;

        index4_sql := null;
        if (mytab.index4 is not null and length(bat_table_name) <= 24) then
          index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_4 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index4 ||
                        ') tablespace ' || mytab.index4_tablespace || ';';
        elsif (mytab.index4 is not null and length(bat_table_name) > 24) then
          index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_4 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index4 || ') tablespace ' ||
                        mytab.index4_tablespace || ';';
        end if;

        index5_sql := null;
        if (mytab.index5 is not null and length(bat_table_name) <= 24) then
          index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_5 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index5 ||
                        ') tablespace ' || mytab.index5_tablespace || ';';
        elsif (mytab.index5 is not null and length(bat_table_name) > 24) then
          index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_5 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index5 || ') tablespace ' ||
                        mytab.index5_tablespace || ';';
        end if;

        index6_sql := null;
        if (mytab.index6 is not null and length(bat_table_name) <= 24) then
          index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_6 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index6 ||
                        ') tablespace ' || mytab.index6_tablespace || ';';
        elsif (mytab.index6 is not null and length(bat_table_name) > 24) then
          index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_6 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index6 || ') tablespace ' ||
                        mytab.index6_tablespace || ';';
        end if;

        index7_sql := null;
        if (mytab.index7 is not null and length(bat_table_name) <= 24) then
          index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_7 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index7 ||
                        ') tablespace ' || mytab.index7_tablespace || ';';
        elsif (mytab.index7 is not null and length(bat_table_name) > 24) then
          index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_7 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index7 || ') tablespace ' ||
                        mytab.index7_tablespace || ';';
        end if;

        index8_sql := null;
        if (mytab.index8 is not null and length(bat_table_name) <= 24) then
          index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        bat_table_name || '_8 on ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.index8 ||
                        ') tablespace ' || mytab.index8_tablespace || ';';
        elsif (mytab.index8 is not null and length(bat_table_name) > 24) then
          index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                        substr(bat_table_name, -24) || '_8 on ' ||
                        mytab.table_owner || '.' || bat_table_name || ' (' ||
                        mytab.index8 || ') tablespace ' ||
                        mytab.index8_tablespace || ';';
        end if;

        begin
          insert into dbm_scheme_table_script
          values
            (mytab.table_owner,
             bat_table_name,
             drop_sql,
             create_sql,
             pk_sql,
             index1_sql,
             index2_sql,
             index3_sql,
             index4_sql,
             index5_sql,
             index6_sql,
             index7_sql,
             index8_sql,
             sysdate);
          commit;
        exception
          when others then
            rollback;
        end;
      end loop;
    end loop;
  end loop;

  for mytab in (select * from DBM_SCHEME_TABLE where tactics = 'RY') loop
    select mytab.table_owner into owner from dual;
    if (owner = 'SO1') then
      codelist(1) := 210;
      codelist(2) := 211;
      codelist(3) := 212;
      codelist(4) := 213;
      codelist(5) := 214;
    elsif (owner = 'SO2') then
      codelist(1) := 215;
      codelist(2) := 216;
      codelist(3) := 217;
      codelist(4) := 218;
      codelist(5) := 219;
    else
      codelist(1) := 210;
      codelist(2) := 211;
      codelist(3) := 212;
      codelist(4) := 213;
      codelist(5) := 214;
      codelist(6) := 215;
      codelist(7) := 216;
      codelist(8) := 217;
      codelist(9) := 218;
      codelist(10) := 219;
    end if;
    for i in codelist.first .. codelist.last loop
      for j in startyear .. endyear loop
          bat_table_name := mytab.table_name || '_' || codelist(i) || '_' || j;
          drop_sql := 'drop table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' cascade constraints;';

          create_sql := 'create table ' || mytab.table_owner || '.' ||
                        bat_table_name || ' (' || mytab.columns_name ||
                        ') tablespace ' || mytab.table_tablespace || ';';

          pk_sql := null;
          if (mytab.pk_names is not null and length(bat_table_name) <= 27) then
            pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' add constraint PK_' ||
                      bat_table_name || ' primary key (' || mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
          elsif (mytab.pk_names is not null and length(bat_table_name) > 27) then
            pk_sql := 'alter table ' || mytab.table_owner || '.' ||
                      bat_table_name || ' add constraint PK_' ||
                      substr(bat_table_name, -27) || ' primary key (' ||
                      mytab.pk_names || ') using index tablespace '||mytab.pk_tablespace||';';
          end if;

          index1_sql := null;
          if (mytab.index1 is not null and length(bat_table_name) <= 24) then
            index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_1 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index1 ||
                          ') tablespace ' || mytab.index1_tablespace || ';';
          elsif (mytab.index1 is not null and length(bat_table_name) > 24) then
            index1_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_1 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index1 || ') tablespace ' ||
                          mytab.index1_tablespace || ';';
          end if;

          index2_sql := null;
          if (mytab.index2 is not null and length(bat_table_name) <= 24) then
            index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_2 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index2 ||
                          ') tablespace ' || mytab.index2_tablespace || ';';
          elsif (mytab.index2 is not null and length(bat_table_name) > 24) then
            index2_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_2 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index2 || ') tablespace ' ||
                          mytab.index2_tablespace || ';';
          end if;

          index3_sql := null;
          if (mytab.index3 is not null and length(bat_table_name) <= 24) then
            index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_3 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index3 ||
                          ') tablespace ' || mytab.index3_tablespace || ';';
          elsif (mytab.index3 is not null and length(bat_table_name) > 24) then
            index3_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_3 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index3 || ') tablespace ' ||
                          mytab.index3_tablespace || ';';
          end if;

          index4_sql := null;
          if (mytab.index4 is not null and length(bat_table_name) <= 24) then
            index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_4 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index4 ||
                          ') tablespace ' || mytab.index4_tablespace || ';';
          elsif (mytab.index4 is not null and length(bat_table_name) > 24) then
            index4_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_4 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index4 || ') tablespace ' ||
                          mytab.index4_tablespace || ';';
          end if;

          index5_sql := null;
          if (mytab.index5 is not null and length(bat_table_name) <= 24) then
            index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_5 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index5 ||
                          ') tablespace ' || mytab.index5_tablespace || ';';
          elsif (mytab.index5 is not null and length(bat_table_name) > 24) then
            index5_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_5 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index5 || ') tablespace ' ||
                          mytab.index5_tablespace || ';';
          end if;

          index6_sql := null;
          if (mytab.index6 is not null and length(bat_table_name) <= 24) then
            index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_6 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index6 ||
                          ') tablespace ' || mytab.index6_tablespace || ';';
          elsif (mytab.index6 is not null and length(bat_table_name) > 24) then
            index6_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_6 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index6 || ') tablespace ' ||
                          mytab.index6_tablespace || ';';
          end if;

          index7_sql := null;
          if (mytab.index7 is not null and length(bat_table_name) <= 24) then
            index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_7 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index7 ||
                          ') tablespace ' || mytab.index7_tablespace || ';';
          elsif (mytab.index7 is not null and length(bat_table_name) > 24) then
            index7_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_7 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index7 || ') tablespace ' ||
                          mytab.index7_tablespace || ';';
          end if;

          index8_sql := null;
          if (mytab.index8 is not null and length(bat_table_name) <= 24) then
            index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          bat_table_name || '_8 on ' || mytab.table_owner || '.' ||
                          bat_table_name || ' (' || mytab.index8 ||
                          ') tablespace ' || mytab.index8_tablespace || ';';
          elsif (mytab.index8 is not null and length(bat_table_name) > 24) then
            index8_sql := 'create index ' || mytab.table_owner || '.IDX_' ||
                          substr(bat_table_name, -24) || '_8 on ' ||
                          mytab.table_owner || '.' || bat_table_name || ' (' ||
                          mytab.index8 || ') tablespace ' ||
                          mytab.index8_tablespace || ';';
          end if;

          begin
            insert into dbm_scheme_table_script
            values
              (mytab.table_owner,
               bat_table_name,
               drop_sql,
               create_sql,
               pk_sql,
               index1_sql,
               index2_sql,
               index3_sql,
               index4_sql,
               index5_sql,
               index6_sql,
               index7_sql,
               index8_sql,
               sysdate);
            commit;
          exception
            when others then
              rollback;
          end;
        end loop;
      end loop;
  end loop;
end prc_dbm_scheme_table_script;
